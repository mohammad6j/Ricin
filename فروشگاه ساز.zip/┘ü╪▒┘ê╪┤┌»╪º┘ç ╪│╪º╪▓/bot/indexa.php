<?php

ob_start();
define('API_KEY','*TOKEN*');
$admin =  "*ADMIN*";
$adminid = *adminid*;
$GetINFObot = json_decode(file_get_contents("https://api.telegram.org/bot".API_KEY."/getMe"));
$UserNameBot = $GetINFObot->result->username;
function save($filename,$TXTdata){
	$myfile = fopen($filename, "w") or die("Unable to open file!");
	fwrite($myfile, "$TXTdata");
	fclose($myfile);
	}
function bot($method,$datas=[]){
    $url = "https://api.telegram.org/bot".API_KEY."/".$method;
    $ch = curl_init();
    curl_setopt($ch,CURLOPT_URL,$url);
    curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($ch,CURLOPT_POSTFIELDS,$datas);
    $res = curl_exec($ch);
    if(curl_error($ch)){
        var_dump(curl_error($ch));
    }else{
        return json_decode($res);
    }
}
function SendMessage($chatid,$text,$parsmde,$disable_web_page_preview,$keyboard){
	bot('sendMessage',[
	'chat_id'=>$chatid,
	'text'=>$text,
	'parse_mode'=>$parsmde,
	'disable_web_page_preview'=>$disable_web_page_preview,
	'reply_markup'=>$keyboard
	]);
	}
function ForwardMessage($chatid,$from_chat,$message_id){
	bot('ForwardMessage',[
	'chat_id'=>$chatid,
	'from_chat_id'=>$from_chat,
	'message_id'=>$message_id
	]);
	}
function SendPhoto($chatid,$photo,$keyboard,$caption){
	bot('SendPhoto',[
	'chat_id'=>$chatid,
	'photo'=>$photo,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendAudio($chatid,$audio,$keyboard,$caption,$sazande,$title){
	bot('SendAudio',[
	'chat_id'=>$chatid,
	'audio'=>$audio,
	'caption'=>$caption,
	'performer'=>$sazande,
	'title'=>$title,
	'reply_markup'=>$keyboard
	]);
	}
function SendDocument($chatid,$document,$keyboard,$caption){
	bot('SendDocument',[
	'chat_id'=>$chatid,
	'document'=>$document,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendSticker($chatid,$sticker,$keyboard){
	bot('SendSticker',[
	'chat_id'=>$chatid,
	'sticker'=>$sticker,
	'reply_markup'=>$keyboard
	]);
	}
function SendVideo($chatid,$video,$keyboard,$duration){
	bot('SendVideo',[
	'chat_id'=>$chatid,
	'video'=>$video,
	'duration'=>$duration,
	'reply_markup'=>$keyboard
	]);
	}
function SendVoice($chatid,$voice,$keyboard,$caption){
	bot('SendVoice',[
	'chat_id'=>$chatid,
	'voice'=>$voice,
	'caption'=>$caption,
	'reply_markup'=>$keyboard
	]);
	}
function SendContact($chatid,$first_name,$phone_number,$keyboard){
	bot('SendContact',[
	'chat_id'=>$chatid,
	'first_name'=>$first_name,
	'phone_number'=>$phone_number,
	'reply_markup'=>$keyboard
	]);
	}
function SendChatAction($chatid,$action){
	bot('sendChatAction',[
	'chat_id'=>$chatid,
	'action'=>$action
	]);
	}
function KickChatMember($chatid,$user_id){
	bot('kickChatMember',[
	'chat_id'=>$chatid,
	'user_id'=>$user_id
	]);
	}
function LeaveChat($chatid){
	bot('LeaveChat',[
	'chat_id'=>$chatid
	]);
	}
function GetChat($chatid){
	bot('GetChat',[
	'chat_id'=>$chatid
	]);
	}
function GetChatMembersCount($chatid){
	bot('getChatMembersCount',[
	'chat_id'=>$chatid
	]);
	}
function GetChatMember($chatid,$userid){
	$truechannel = json_decode(file_get_contents('https://api.telegram.org/bot'.API_KEY."/getChatMember?chat_id=".$chatid."&user_id=".$userid));
	$tch = $truechannel->result->status;
	return $tch;
	}
function AnswerCallbackQuery($callback_query_id,$text,$show_alert){
	bot('answerCallbackQuery',[
        'callback_query_id'=>$callback_query_id,
        'text'=>$text,
		'show_alert'=>$show_alert
    ]);
	}
function EditMessageText($chat_id,$message_id,$text,$parse_mode,$disable_web_page_preview,$keyboard){
	 bot('editMessagetext',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'text'=>$text,
    'parse_mode'=>$parse_mode,
	'disable_web_page_preview'=>$disable_web_page_preview,
    'reply_markup'=>$keyboard
	]);
	}
function EditMessageCaption($chat_id,$message_id,$caption,$keyboard,$inline_message_id){
	 bot('editMessageCaption',[
    'chat_id'=>$chat_id,
	'message_id'=>$message_id,
    'caption'=>$caption,
    'reply_markup'=>$keyboard,
	'inline_message_id'=>$inline_message_id
	]);
	}
	
$button_tiid = json_encode(['keyboard'=>[
[['text'=>'تایید شماره','request_contact'=>true]],
[['text'=>'چرا باید شمارمو تایید کنم']],
],'resize_keyboard'=>true]);
$button_manage = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
[['text'=>'پیام همگانی'],['text'=>'فوروارد همگانی']],
[['text'=>'آمار'],['text'=>'تعیین کد رایگان']],
[
['text'=>'اهدای سکه'],['text'=>'کم کردن سکه']
],
],'resize_keyboard'=>true]);
$button_official = json_encode(['keyboard'=>[
[['text'=>'💎جمع آوری سکه رایگان💎']],
[['text'=>'فروشگاه💌'],['text'=>'انتقال سکه♻️'],['text'=>'ثبت تبلیغات 📝']],
[['text'=>'👤زیرمجموعه گیری'],['text'=>'حساب کاربری من😎']],
[['text'=>'نظرات کاربران به ربات📧']],
[['text'=>'ارتباط با ما😉'],['text'=>'راهنما📕']],
[['text'=>'🎁 کد رایگان 🎉']],
],'resize_keyboard'=>true]);
$button_back = json_encode(['keyboard'=>[
[['text'=>'↩️منوی اصلی']],
],'resize_keyboard'=>true]);
$button_nz = json_encode(['inline_keyboard'=>[
[['text'=>'نظر بعدی','callback_data'=>'nzr']],
],'resize_keyboard'=>true]);
$button_nza = json_encode(['inline_keyboard'=>[
[['text'=>'تایید نظر','callback_data'=>'taiid nzr'],['text'=>'رد نظر','callback_data'=>'rad nzr']],
],'resize_keyboard'=>true]);

$update = json_decode(file_get_contents('php://input'));
$data = $update->callback_query->data;
$chatid = $update->callback_query->message->chat->id;
$fromid = $update->callback_query->message->from->id;
$messageid = $update->callback_query->message->message_id;
$data_id = $update->callback_query->id;
$txt = $update->callback_query->message->text;
$chat_id = $update->message->chat->id;
$from_id = $update->message->from->id;
$from_username = $update->message->from->username;
$from_first = $update->message->from->first_name;
$forward_id = $update->message->forward_from->id;
$forward_chat = $update->message->forward_from_chat;
$forward_chat_username = $update->message->forward_from_chat->username;
$forward_chat_msg_id = $update->message->forward_from_message_id;
$text = $update->message->text;
$message_id = $update->message->message_id;
$stickerid = $update->message->sticker->file_id;
$videoid = $update->message->video->file_id;
$voiceid = $update->message->voice->file_id;
$fileid = $update->message->document->file_id;
$photo = $update->message->photo;
$photoid = $photo[count($photo)-1]->file_id;
$musicid = $update->message->audio->file_id;
$caption = $update->message->caption;
$cde = time();
$code = md5("$cde$from_id");
$command = file_get_contents('user/'.$from_id."/command.txt");
$gold = file_get_contents('user/'.$from_id."/gold.txt");
$coin = file_get_contents('user/'.$from_id."/coin.txt");
$wait = file_get_contents('user/'.$from_id."/wait.txt");
$coin_wait = file_get_contents('user/'.$wait."/coin.txt");
$number = file_get_contents('user/'.$from_id."/number.txt");
$code_taiid = file_get_contents('user/'.$from_id."/code taiid.txt");
$Member = file_get_contents('admin/Member.txt');
$NZR = file_get_contents('admin/NZR.txt');
$Tedad_Nazar = file_get_contents('admin/Tedad Nazar.txt');
$ads = file_get_contents('ads/Ads.txt');

// start source
    if (strpos($block , "$from_id") !== false) {
	return false;
	}
	elseif ($from_id != $chat_id and $chat_id != $feed) {
	LeaveChat($chat_id);
	}
	//===============
  elseif($data == 'taiid nzr'){
  AnswerCallbackQuery($data_id,'نظر تایید شد');
  EditMessageText($chatid,$messageid,"نظر تایید شد",'html','true');
  file_put_contents("admin/NZR.txt","$NZR\n(**##**)\n$txt");
  }
  elseif($data == 'rad nzr'){
  AnswerCallbackQuery($data_id,'نظر رد شد');
  EditMessageText($chatid,$messageid,"نظر رد شد",'html','true');
  }
  //===============
  elseif($data == 'nzr'){
  $exp = explode("(**##**)",$NZR);
  $rand = $exp[rand(0,count($exp)-1)];
  $txtt = file_get_contents('admin/Tedad Nazar.txt');
  $member_id = explode("\n",$txtt);
  $mmemcount = count($member_id) -1;
  if($rand == null || $rand == '' || $rand == "\n"){
  EditMessageText($chatid,$messageid,"نظر موجود نیس",'html','true');
  }else{
  AnswerCallbackQuery($data_id,'نظر بعدی');
  EditMessageText($chatid,$messageid,"نظرات: $mmemcount
  
  $rand",'html','true',$button_nz);
  }
  }
  //===============
	elseif(preg_match('/^\/([Ss]tart)(.*)/',$text)){
	preg_match('/^\/([Ss]tart)(.*)/',$text,$match);
	$match[2] = str_replace(" ","",$match[2]);
	$match[2] = str_replace("\n","",$match[2]);
	if($match[2] != null){
	if (strpos($Member , "$from_id") == false){
	if($match[2] != $from_id){
	if (strpos($gold , "$from_id") == false){
	$txxt = file_get_contents('user/'.$match[2]."/gold.txt");
    $pmembersid= explode("\n",$txxt);
    if (!in_array($from_id,$pmembersid)){
      $aaddd = file_get_contents('user/'.$match[2]."/gold.txt");
      $aaddd .= $from_id."\n";
		file_put_contents('user/'.$match[2]."/gold.txt",$aaddd);
    }
	$mtch = file_get_contents('user/'.$match[2]."/coin.txt");
	file_put_contents("user/".$match[2]."/coin.txt",($mtch+1) );
	SendMessage($match[2],"🆕 یک نفر با لینک اختصاصی شما وارد ربات شد","html","true",$button_official);
	}
	}
	}
	}
	SendMessage($chat_id,"به آسانی و در چند کلیک ربات سین ساز خود را بسازید\nIronTM_botsaz_bot\nIronTM_botsaz_bot");
	SendMessage($chat_id," سلام خوش اومدی. چه کاری انجام دهم؟","html","true",$button_official);
	}
	//================
	elseif($update->message->contact and $number == null){
	$rand = rand(11111,55555);
	$ce = $rand;
	file_put_contents('user/'.$from_id."/code taiid.txt",$ce);
	file_put_contents('user/'.$from_id."/command.txt","taiid nashode");
	file_put_contents('user/'.$from_id."/number.txt",$update->message->contact->phone_number);
	SendMessage($chat_id,"خوب حالا کد $ce رو وارد کنید تا ربات فعال شود","html","true",$button_tiid);
	}
	//================
	elseif($command == "taiid nashode"){
	if($text == $code_taiid){
	file_put_contents('user/'.$from_id."/command.txt","none");
	SendMessage($chat_id,"تایید شدید","html","true",$button_official);
	}else{
	SendMessage($chat_id,"کد اشتباه","html","true");
	}
	}
	//===============
  elseif($text == 'چرا باید شمارمو تایید کنم'){
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"به این دلیل","html","true");
  }
	//================
	elseif($number == null){
	SendMessage($chat_id,"حتما باید شمارتونو تایید کنید","html","true",$button_tiid);
	}
	//===============
  elseif($text == '↩️منوی اصلی'){
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"↩️ شما به منوی اصلی برگشتید

⏺ چه کاری میتونم براتون انجام بدم؟","html","true",$button_official);
  }
	//===============
  elseif(preg_match('/^\/([Cc]reator)/',$text)){
  SendMessage($chat_id,"[این ربات توسط ربات ساز شاپ ساز تیاک تیم ساخته شده است](https://t.me/aa6)");
  }
	//===============
  elseif($text == 'فروشگاه💌'){
  SendMessage($chat_id,"💰قیمت :هزار تومان
200 سکه💰
💰قیمت:دوهزار تومان
500 سکه 💰
💰قیمت :چهار هزار تومان
700 سکه💰
💰قیمت : پنج هزار تومان
1000 سکه💰
💰قیمت : ده هزار تومان
2500 سکه💰
نوع خرید
کارت به کارت 💳
جهت خریدو اطلاعات به ایدی های زیر پیام دهید
@$adminid","html","true",$button_official);
  }
  //===============
  elseif($text == '👤زیرمجموعه گیری'){
  $member_id = explode("\n",$gold);
  $mmemcount = count($member_id) -1;
  SendMessage($chat_id,"http://telegram.me/$UserNameBot?start=$from_id
  
  تعداد زیرمجموعه های شما: $mmemcount","html","true",$button_official);
  }
  //===============
  elseif($text == 'راهنما📕'){
  SendMessage($chat_id,"راهنما","html","true",$button_official);
  }
  //===============
  elseif($text == 'حساب کاربری من😎'){
  SendMessage($chat_id,"موجودی شما: $coin
  شماره کاربری شما: $from_id","html","true",$button_official);
  }
  //===============
  elseif($text == 'نظرات کاربران به ربات📧'){
  $exp = explode("(**##**)",$NZR);
  $rand = $exp[rand(0,count($exp)-1)];
  if($rand == null || $rand == '' || $rand == "\n"){
  SendMessage($chat_id,"نظر موجود نیس","html","true");
  }else{
  $txtt = file_get_contents('admin/Tedad Nazar.txt');
  $member_id = explode("\n",$txtt);
  $mmemcount = count($member_id) -1;
  SendMessage($chat_id,"نظرات: $mmemcount
  
  $rand","html","true",$button_nz);
  }
  }
  //===============
  elseif($text == 'انتقال سکه♻️'){
  file_put_contents('user/'.$from_id."/command.txt","send coin");
  SendMessage($chat_id,"شماره کاربری مقصد رو وارد کنید:","html","true",$button_back);
  }
  elseif($command == 'send coin'){
  $explode = explode("\n",$Member);
  if($text != $from_id && in_array($text,$explode)){
  file_put_contents('user/'.$from_id."/command.txt","send coin2");
  file_put_contents('user/'.$from_id."/wait.txt",$text);
  SendMessage($chat_id,"مقدار سکه شما: $coin
  چه تعداد سکه میخوای انتقال بدی","html","true",$button_back);
  }else{
  SendMessage($chat_id,"شناسه کاربری نا معتبره یا شناسه کاربری خودتون رو وارد کردین","html","true",$button_back);
  }
  }
  elseif($command == 'send coin2'){
  if(preg_match('/^([0-9])/',$text)){
  if($text > $coin){
  SendMessage($chat_id,"مقدار سکه شما $coin میباشد
  میتونید به اندازهس که خودتون انتقال بدین","html","true",$button_back);
  }else{
  file_put_contents("user/$wait/coin.txt",($coin_wait+$text) );
  file_put_contents("user/$from_id/coin.txt",($coin-$text) );
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"انتقال داده شد","html","true",$button_official);
  }
  }else{
  SendMessage($chat_id,"فقط باید عدد وارد کنید","html","true",$button_back);
  }
  }
  //===============
  elseif($text == 'ارتباط با ما😉'){
  file_put_contents('user/'.$from_id."/command.txt","contact");
  SendMessage($chat_id,"خوشحالیم که میخواهید نظر بدهید. نظر خود را ارسال کنید به سرعت به دست فول تیم میرسد","html","true",$button_back);
  }
  elseif($command == 'contact'){
  if($text){
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"ثبت شد","html","true",$button_official);
  if($from_username == null){
  $from_username = '---';
  }else{
  $from_username = "@$from_username";
  }
  SendMessage($admin,"$from_id
  $from_first
  $from_username
  
  $text","html","true",$button_nza);
  file_put_contents("admin/Tedad Nazar.txt","$Tedad_Nazar\n$from_id");
  }else{
  SendMessage($chat_id,"فقط متن","html","true",$button_back);
  }
  }
  //===============
  elseif($text == 'ثبت تبلیغات 📝'){
  if($coin < 30){
  SendMessage($chat_id,"حداقل سکه باید 30 باشد","html","true");
  }else{
  file_put_contents('user/'.$from_id."/command.txt","set ads");
  if( ($coin%2) == 0){
  $coin = $coin;
  }else{
  $coin = $coin-1;
  }
  $cn = $coin / 2;
  SendMessage($chat_id,"شما میتونید $cn بازدید برای پست بزنید","html","true",$button_back);
  }
  }
  elseif($command == 'set ads'){
  if(preg_match('/^([0-9])/',$text)){
  if($coin%2 == 0){
  $coin = $coin;
  }else{
  $coin = $coin-1;
  }
  $cn = $coin / 2;
  if ($cn < $text){
  SendMessage($chat_id,"شما میتونید تعداد درخواستیی سین خود را بنویسید $cn بازدید برای پست بزنید","html","true",$button_back);
  }else{
  file_put_contents('user/'.$from_id."/wait.txt",$text);
  file_put_contents('user/'.$from_id."/command.txt","set ads2");
  SendMessage($chat_id,"پیامو فوروارد کنید","html","true",$button_back);
  }
  }else{
  SendMessage($chat_id,"فقط باید عدد وارد کنید","html","true",$button_back);
  }
  }
  elseif($command == 'set ads2'){
  $cd = $code;
  if($forward_chat_username != null){
  file_put_contents('user/'.$from_id."/command.txt","none");
  file_put_contents("ads/ads msg id/$cd.txt",$forward_chat_msg_id);
  file_put_contents("ads/ads tedad/$cd.txt",$wait);
  file_put_contents("ads/ads username/$cd.txt","@$forward_chat_username");
  file_put_contents("ads/ads tally/$cd.txt",'');
  file_put_contents("ads/Ads.txt","$cd\n$ads");
  file_put_contents("ads/ads admin/$cd.txt",$from_id);
  file_put_contents("user/$from_id/coin.txt",($coin - ($wait*2)) );
  SendMessage($chat_id,"ثبت شد
  
  کد سفارش: $cd","html","true",$button_official);
  }else{
  SendMessage($chat_id,"باید از کانال عمومی فور کنین","html","true");
  }
  }
  //===============
  elseif($text == '💎جمع آوری سکه رایگان💎'){
  $exp = explode("\n",$ads);
  $rnd = $exp[rand(0,count($exp)-1)];
  $rand = $rnd;
  $adn = file_get_contents("ads/ads admin/$rand.txt");
  if($rand == null || $rand == '' || $rand == "\n" || $from_id == $adn){
  SendMessage($chat_id,"تبلیغ موجود نیست","html","true");
  }else{
  $msg_id = file_get_contents("ads/ads msg id/$rand.txt");
  $msg_user = file_get_contents("ads/ads username/$rand.txt");
  ForwardMessage($chat_id,$msg_user,$msg_id);
  
   $usr = file_get_contents("ads/ads tally/$rand.txt");
    $pmembersid = explode("\n",$usr);
    if (!in_array($from_id,$pmembersid)){
		$aaddd = file_get_contents("ads/ads tally/$rand.txt");
        $aaddd .= $from_id."\n";
		file_put_contents("ads/ads tally/$rand.txt",$aaddd);
    }
	
    $member_id = explode("\n",$usr);
    $mmemcount = count($member_id);
	$tdd = file_get_contents("ads/ads tedad/$rand.txt");
	
	if($mmemcount >= $tdd){
	SendMessage($adn,"سفارش تبلیغ با کد پیگیری $rand تموم شد.","html","true");
	$str = str_replace("\n$rand",'',$ads);
	$str = str_replace("$rand",'',$ads);
	file_put_contents("ads/Ads.txt",$str);
	unlink("ads/ads msg id/$rand.txt");
    unlink("ads/ads tedad/$rand.txt");
    unlink("ads/ads username/$rand.txt");
    unlink("ads/ads tally/$rand.txt");
    unlink("ads/ads admin/$rand.txt");
	}
	}
  }
  //===============
  elseif($text == '🎁 کد رایگان 🎉'){
  file_put_contents('user/'.$from_id."/command.txt","free code");
  SendMessage($chat_id,"کد مورد نظر رو وارد کنید","html","true",$button_back);
  }
  elseif($command == 'free code'){
  if(file_exists("admin/code/$text.txt")){
  $cde = file_get_contents("admin/code/$text.txt");
  $exp = explode("\n",$cde);
  if(in_array($from_id,$exp)){
  file_put_contents('user/'.$from_id."/command.txt","none");
  SendMessage($chat_id,"شما قبلا استفاده کردین","html","true",$button_official);
  }else{
  file_put_contents('user/'.$from_id."/command.txt","none");
  file_put_contents('user/'.$from_id."/coin.txt",($coin+200));
  file_put_contents("admin/code/$text.txt","$cde\n$from_id");
  SendMessage($chat_id,"تعداد 200 سکه رایگان به شما اضافه شد.","html","true",$button_official);
  }
  }else{
  SendMessage($chat_id,"کد وجود نداشت","html","true",$button_back);
  }
  }
  //===============
  elseif($text == '/panel' and $from_id == $admin){
  SendMessage($chat_id,"به پنل مدیریت خوش اومدی","html","true",$button_manage);
  }
  elseif($text == 'آمار' and $from_id == $admin){
	$txtt = file_get_contents('admin/Member.txt');
    $member_id = explode("\n",$txtt);
    $mmemcount = count($member_id) -1;
	SendMessage($chat_id,"کل کاربران: $mmemcount نفر","html","true");
	}
  elseif($text == 'فوروارد همگانی' and $from_id == $admin){
	file_put_contents("user/".$from_id."/command.txt","s2a fwd");
	SendMessage($chat_id,"پیام مورد نظر را فوروارد کنید","html","true",$button_back);
	}
	elseif($command == 's2a fwd' and $from_id == $admin){
	file_put_contents("user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "admin/Member.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			ForwardMessage($user,$admin,$message_id);
		}
	}
	elseif($text == 'پیام همگانی' and $from_id == $admin){
	file_put_contents("user/".$from_id."/command.txt","s2a");
	SendMessage($chat_id,"پیامتون رو وارد کنید","html","true",$button_back);
	}
	elseif($command == 's2a' and $from_id == $admin){
	file_put_contents("user/".$from_id."/command.txt","none");
	SendMessage($chat_id,"پیام شما در صف ارسال قرار گرفت.","html","true",$button_manage);
	$all_member = fopen( "admin/Member.txt", 'r');
		while( !feof( $all_member)) {
 			$user = fgets( $all_member);
			if($sticker_id != null){
			SendSticker($user,$stickerid);
			}
			elseif($videoid != null){
			SendVideo($user,$videoid,$caption);
			}
			elseif($voiceid != null){
			SendVoice($user,$voiceid,'',$caption);
			}
			elseif($fileid != null){
			SendDocument($user,$fileid,'',$caption);
			}
			elseif($musicid != null){
			SendAudio($user,$musicid,'',$caption);
			}
			elseif($photoid != null){
			SendPhoto($user,$photoid,'',$caption);
			}
			elseif($text != null){
			SendMessage($user,$text,"html","true");
			}
		}
	}
  elseif($text == 'تعیین کد رایگان' and $from_id == $admin){
  file_put_contents('user/'.$from_id."/command.txt","code free2");
  SendMessage($chat_id,"کد مورد نظر رو وارد کنید","html","true",$button_back);
  }
  elseif($command == 'code free2' and $from_id == $admin){
  file_put_contents("admin/code/$text.txt","");
  file_put_contents("user/".$from_id."/command.txt","none");
  SendMessage($chat_id,"کد ثبت شد.","html","true",$button_manage);
  }
  // End Source
  if(!file_exists('user/'.$from_id)){
  mkdir('user/'.$from_id);
  }
  if(!file_exists('user/'.$from_id."/coin.txt")){
  file_put_contents('user/'.$from_id."/coin.txt","1");
  }
  $txxt = file_get_contents('admin/Member.txt');
    $pmembersid= explode("\n",$txxt);
    if (!in_array($chat_id,$pmembersid)){
      $aaddd = file_get_contents('admin/Member.txt');
      $aaddd .= $chat_id."\n";
		file_put_contents('admin/Member.txt',$aaddd);
    }unlink('error_log');
    if (strpos($text,"/addcoin") !== false && $from_id == $admin) {
  $textt = explode(" ",$text);
  if ($textt['2'] != "" && $textt['1'] != "") {
    $coin = file_get_contents("user/".$textt['1']."/coin.txt");
    settype($coin,"integer");
    $newcoin = $coin + $textt['2'];
    save("user/".$textt['1']."/coin.txt",$newcoin);
    SendMessage($textt['1'],"تعداد ".$textt['2']." الماس به شما اضافه شد");
  }
  else {
    SendMessage($chat_id,"Syntax Error!");
  }
}
if (strpos($text,"/getcoin") !== false && $from_id == $admin) {
  $textt = explode(" ",$text);
  if ($textt['2'] != "" && $textt['1'] != "") {
    $coin = file_get_contents("user/".$textt['1']."/coin.txt");
    settype($coin,"integer");
    $newcoin = $coin - $textt['2'];
    save("user/".$textt['1']."/coin.txt",$newcoin);
    SendMessage($textt['1'],"تعداد ".$textt['2']." الماس از شما کم شد");
  }
  else {
    SendMessage($chat_id,"Syntax Error!");
  }
}
 if ($text == 'اهدای سکه') {
    if ($from_id = $admin) {
    sendmessage($chat_id,"ادمین عزیز برای اهدای سکه از دستور\n/addcoin USERID COIN\nاستفاده کنید");
    }else{
    sendmessage($chat_id,"شما ادمین نیستید");
    }
    }
    if ($text == 'کم کردن سکه') {
    if ($from_id = $admin) {
    sendmessage($chat_id,"ادمین عزیز برای کم کردن سکه از دستور\n/getcoin USERID COIN\nاستفاده کنید");
    }else{
    sendmessage($chat_id,"شما ادمین نیستید");
    }
    }
	?>